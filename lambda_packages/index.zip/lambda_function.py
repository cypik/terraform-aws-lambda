def handler(event, context): import time; time.sleep(10); return {"statusCode": 200, "body": "Hello cypik.com"}
